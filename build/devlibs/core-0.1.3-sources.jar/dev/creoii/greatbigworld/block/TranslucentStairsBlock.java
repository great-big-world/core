package dev.creoii.greatbigworld.block;

import net.minecraft.block.BlockState;
import net.minecraft.block.StairsBlock;
import net.minecraft.block.enums.StairShape;
import net.minecraft.util.math.Direction;

public class TranslucentStairsBlock extends StairsBlock {
    public TranslucentStairsBlock(BlockState baseBlockState, Settings settings) {
        super(baseBlockState, settings);
    }

    protected boolean isSideInvisible(BlockState state, BlockState stateFrom, Direction direction) {
        if (stateFrom.isOf(this)) {
            if (stateFrom.get(StairsBlock.FACING) == direction && state.get(StairsBlock.FACING) != direction.getOpposite()) {
                return false;
            } else if (stateFrom.get(StairsBlock.FACING) == direction && stateFrom.get(StairsBlock.SHAPE) == StairShape.INNER_LEFT && (state.get(StairsBlock.FACING) == Direction.values()[direction.getId() + 1] || state.get(StairsBlock.FACING) == Direction.values()[direction.getId() - 1])) {
                return false;
            } else return true;
        }
        return super.isSideInvisible(state, stateFrom, direction);
    }
}
