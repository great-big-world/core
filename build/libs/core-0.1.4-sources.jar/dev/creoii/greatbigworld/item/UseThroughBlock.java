package dev.creoii.greatbigworld.item;

import dev.creoii.greatbigworld.GreatBigWorld;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public interface UseThroughBlock {
    default void onAttackThroughBlock(class_1657 player, class_1799 stack, class_1297 target) {}

    default boolean canAttackThroughBlock(class_1657 player, class_1799 stack, class_1297 target) {
        return false;
    }

    record AttackThroughBlock(int entityId) implements class_8710 {
        public static final class_8710.class_9154<AttackThroughBlock> PACKET_ID = new class_8710.class_9154<>(class_2960.method_60655(GreatBigWorld.NAMESPACE, "attack_through_block"));
        public static final class_9139<class_9129, AttackThroughBlock> PACKET_CODEC = class_9139.method_56438(AttackThroughBlock::write, AttackThroughBlock::new);

        public AttackThroughBlock(class_9129 buf) {
            this(buf.method_10816());
        }

        public void write(class_9129 buf) {
            buf.method_10804(entityId);
        }

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return PACKET_ID;
        }
    }
}
