package dev.creoii.greatbigworld.block;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

public interface OverlayState {
    @Environment(EnvType.CLIENT)
    default class_2680 getOverlayState(class_2680 state, class_2338 pos, class_5819 random) {
        return class_2246.field_10124.method_9564();
    }
}
