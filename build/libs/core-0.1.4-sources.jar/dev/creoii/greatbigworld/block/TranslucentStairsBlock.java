package dev.creoii.greatbigworld.block;

import net.minecraft.class_2350;
import net.minecraft.class_2510;
import net.minecraft.class_2680;
import net.minecraft.class_2760;
import net.minecraft.class_2778;

public class TranslucentStairsBlock extends class_2510 {
    public TranslucentStairsBlock(class_2680 baseBlockState, class_2251 settings) {
        super(baseBlockState, settings);
    }

    protected boolean method_9522(class_2680 state, class_2680 stateFrom, class_2350 direction) {
        if (stateFrom.method_27852(this)) {
            class_2350 stateFacing = state.method_11654(class_2510.field_11571);
            class_2760 stateHalf = state.method_11654(class_2510.field_11572);
            class_2778 stateShape = state.method_11654(class_2510.field_11565);

            class_2350 otherFacing = stateFrom.method_11654(class_2510.field_11571);
            class_2760 otherHalf = stateFrom.method_11654(class_2510.field_11572);
            class_2778 otherShape = stateFrom.method_11654(class_2510.field_11565);

            if (direction == class_2350.field_11036) {
                return otherHalf == class_2760.field_12619 && stateHalf == class_2760.field_12619 && otherFacing == stateFacing;
            } else if (direction == class_2350.field_11033) {
                return otherHalf == class_2760.field_12617 && stateHalf == class_2760.field_12617 && otherFacing == stateFacing;
            }

            if (direction.method_10153() == stateFacing) {
                return otherFacing == stateFacing && otherShape == stateShape && stateHalf == otherHalf;
            }

            if (stateShape == class_2778.field_12712 || stateShape == class_2778.field_12713 || stateShape == class_2778.field_12708 || stateShape == class_2778.field_12709) {
                return stateShape == otherShape && stateFacing == otherFacing && stateHalf == otherHalf;
            }
        }

        return super.method_9522(state, stateFrom, direction);
    }
}
