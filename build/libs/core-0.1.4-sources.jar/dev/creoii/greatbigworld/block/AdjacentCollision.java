package dev.creoii.greatbigworld.block;

import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface AdjacentCollision {
    default boolean canEntityCollideAdjacent(class_1297 entity, class_2680 state, class_2338 pos) {
        return false;
    }

    default void onAdjacentEntityCollision(class_1297 entity, class_2680 state, class_2338 pos) {
    }
}
