package dev.creoii.greatbigworld.block;

import net.minecraft.class_2350;
import net.minecraft.class_2482;
import net.minecraft.class_2680;
import net.minecraft.class_2771;

public class TranslucentSlabBlock extends class_2482 {
    public TranslucentSlabBlock(class_2251 settings) {
        super(settings);
    }

    protected boolean method_9522(class_2680 state, class_2680 other, class_2350 direction) {
        if (other.method_27852(this)) {
            if (state.method_11654(class_2482.field_11501) == class_2771.field_12682 && direction == class_2350.field_11036 && other.method_11654(class_2482.field_11501) == class_2771.field_12681)
                return true;
            else if (state.method_11654(class_2482.field_11501) == class_2771.field_12682 && direction == class_2350.field_11033 && other.method_11654(class_2482.field_11501) == class_2771.field_12679)
                return true;

            return other.method_11654(class_2482.field_11501) == state.method_11654(class_2482.field_11501) || other.method_11654(class_2482.field_11501) == class_2771.field_12682;
        }
        return super.method_9522(state, other, direction);
    }
}
