package dev.creoii.greatbigworld.block;

import net.minecraft.class_2350;
import net.minecraft.class_2544;
import net.minecraft.class_2680;

public class TranslucentWallBlock extends class_2544 {
    public TranslucentWallBlock(class_2251 settings) {
        super(settings);
    }

    protected boolean method_9522(class_2680 state, class_2680 stateFrom, class_2350 direction) {
        return stateFrom.method_27852(this) || super.method_9522(state, stateFrom, direction);
    }
}
