package dev.creoii.greatbigworld.worldgen;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.creoii.greatbigworld.GreatBigWorld;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_5444;
import net.minecraft.class_5819;
import net.minecraft.class_6661;
import net.minecraft.class_6797;
import net.minecraft.class_6798;
import net.minecraft.class_7923;

public class AllOfPlacementModifier extends class_6661 {
    public static final MapCodec<AllOfPlacementModifier> CODEC = RecordCodecBuilder.mapCodec(instance -> {
        return instance.group(class_6797.field_35736.listOf().fieldOf("placements").forGetter(predicate -> {
            return predicate.placements;
        })).apply(instance, AllOfPlacementModifier::new);
    });
    private final List<class_6797> placements;

    public AllOfPlacementModifier(List<class_6797> placements) {
        this.placements = placements;
        if (placements.size() == 1) {
            GreatBigWorld.LOGGER.error("Instance of {} contains 1 placement entry. This is redundant.", class_7923.field_41148.method_10221(method_39615()));
        }
    }

    @Override
    public class_6798<?> method_39615() {
        return GBWPlacementModifiers.ALL_OF;
    }

    @Override
    public boolean method_38918(class_5444 context, class_5819 random, class_2338 pos) {
        for (class_6797 modifier : placements) {
            if (modifier instanceof class_6661 conditional && !conditional.method_38918(context, random, pos)) {
                return false;
            }
        }
        return true;
    }
}
