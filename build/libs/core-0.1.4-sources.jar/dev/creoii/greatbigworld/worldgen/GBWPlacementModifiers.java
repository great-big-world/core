package dev.creoii.greatbigworld.worldgen;

import dev.creoii.greatbigworld.GreatBigWorld;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_6798;
import net.minecraft.class_7923;

public class GBWPlacementModifiers {
    public static final class_6798<NoisePlacementModifier> NOISE = () -> NoisePlacementModifier.CODEC;

    public static final class_6798<AnyOfPlacementModifier> ANY_OF = () -> AnyOfPlacementModifier.CODEC;

    public static final class_6798<AllOfPlacementModifier> ALL_OF = () -> AllOfPlacementModifier.CODEC;

    public static void register() {
        class_2378.method_10230(class_7923.field_41148, class_2960.method_60655(GreatBigWorld.NAMESPACE, "noise"), NOISE);
        class_2378.method_10230(class_7923.field_41148, class_2960.method_60655(GreatBigWorld.NAMESPACE, "any_of"), ANY_OF);
        class_2378.method_10230(class_7923.field_41148, class_2960.method_60655(GreatBigWorld.NAMESPACE, "all_of"), ALL_OF);
    }
}
