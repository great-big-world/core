package dev.creoii.greatbigworld.worldgen;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2338;
import net.minecraft.class_3215;
import net.minecraft.class_5216;
import net.minecraft.class_5321;
import net.minecraft.class_5444;
import net.minecraft.class_5819;
import net.minecraft.class_6661;
import net.minecraft.class_6798;
import net.minecraft.class_7924;

public class NoisePlacementModifier extends class_6661 {
        public static final MapCodec<NoisePlacementModifier> CODEC = RecordCodecBuilder.mapCodec(instance -> {
        return instance.group(class_5321.method_39154(class_7924.field_41244).fieldOf("noise").forGetter(predicate -> {
            return predicate.noise;
        }), Codec.DOUBLE.optionalFieldOf("min_threshold", -1d).forGetter(predicate -> {
            return predicate.minThreshold;
        }), Codec.DOUBLE.optionalFieldOf("max_threshold", 1d).forGetter(predicate -> {
            return predicate.maxThreshold;
        })).apply(instance, NoisePlacementModifier::new);
    });
    private final class_5321<class_5216.class_5487> noise;
    private final double minThreshold;
    private final double maxThreshold;

    public NoisePlacementModifier(class_5321<class_5216.class_5487> noise, double minThreshold, double maxThreshold) {
        this.noise = noise;
        this.minThreshold = minThreshold;
        this.maxThreshold = maxThreshold;
    }

    @Override
    public class_6798<?> method_39615() {
        return GBWPlacementModifiers.NOISE;
    }

    @Override
    public boolean method_38918(class_5444 context, class_5819 random, class_2338 pos) {
        if (context.method_34383().method_8398() instanceof class_3215 chunkManager) {
            class_5216 sampler = chunkManager.method_41248().method_41558(noise);
            double noiseValue = sampler.method_27406(pos.method_10263(), pos.method_10264(), pos.method_10260());
            return noiseValue >= minThreshold && noiseValue <= maxThreshold;
        }
        return false;
    }
}