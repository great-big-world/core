package dev.creoii.greatbigworld.tag;

import dev.creoii.greatbigworld.GreatBigWorld;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public final class GBWBlockTags {
    public static final class_6862<class_2248> WEATHER_RENDER_IGNORES = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655(GreatBigWorld.NAMESPACE, "weather_render_ignores"));
}
