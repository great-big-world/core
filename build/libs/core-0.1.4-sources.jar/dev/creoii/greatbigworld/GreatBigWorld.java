package dev.creoii.greatbigworld;

import dev.creoii.greatbigworld.item.UseThroughBlock;
import dev.creoii.greatbigworld.worldgen.GBWPlacementModifiers;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class GreatBigWorld implements ModInitializer {
    public static final String NAMESPACE = "great_big_world";
    public static final Logger LOGGER = LogManager.getLogger(GreatBigWorld.class);

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(UseThroughBlock.AttackThroughBlock.PACKET_ID, UseThroughBlock.AttackThroughBlock.PACKET_CODEC);

        GBWPlacementModifiers.register();

        ServerPlayNetworking.registerGlobalReceiver(UseThroughBlock.AttackThroughBlock.PACKET_ID, (payload, context) -> {
            int entityId = payload.entityId();
            context.server().execute(() -> {
                class_3222 serverPlayer = context.player();
                if (serverPlayer.method_5682() != null) {
                    class_1799 stack = serverPlayer.method_5998(serverPlayer.method_6058());
                    if (stack.method_7909() instanceof UseThroughBlock useThroughBlock) {
                        class_1297 entity = serverPlayer.method_37908().method_8469(entityId);
                        if (entity != null && useThroughBlock.canAttackThroughBlock(serverPlayer, stack, entity)) {
                            serverPlayer.method_7324(entity);
                            useThroughBlock.onAttackThroughBlock(serverPlayer, stack, entity);
                        }
                    }
                }
            });
        });
    }
}
