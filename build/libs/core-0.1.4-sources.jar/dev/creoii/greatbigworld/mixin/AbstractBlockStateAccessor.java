package dev.creoii.greatbigworld.mixin;

import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4970.class_4971.class)
public interface AbstractBlockStateAccessor {
    @Accessor
    int getLuminance();

    @Accessor("luminance")
    void setLuminance(int luminance);
}
