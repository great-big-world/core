package dev.creoii.greatbigworld.mixin.client;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.function.Consumer;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_342;
import net.minecraft.class_525;
import net.minecraft.class_7919;
import net.minecraft.class_8100;

@Mixin(class_525.class_8093.class)
public class CreateWorldScreenGameTabMixin {
    @Shadow @Final private class_342 worldNameField;
    @Shadow @Final class_525 field_42174;

    @Redirect(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screen/world/WorldCreator;addListener(Ljava/util/function/Consumer;)V", ordinal = 0))
    private void gbw$addGBWPrefixToWorldDirectoryName(class_8100 instance, Consumer<class_8100> listener) {
        field_42174.method_48657().method_48712((creator) -> {
            this.worldNameField.method_47400(class_7919.method_47407(class_2561.method_43469("selectWorld.targetFolder", class_2561.method_43470("gbw/" + /*FileSystems.getDefault().getSeparator() +*/ creator.method_49703()).method_27692(class_124.field_1056))));
        });
    }
}
