package dev.creoii.greatbigworld.mixin.client;

import dev.creoii.greatbigworld.item.UseThroughBlock;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1675;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public class ClientPlayerInteractionManagerMixin {
    @Shadow @Final private class_310 client;

    @Inject(method = "attackBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/GameMode;isCreative()Z"))
    private void creo$tryAttackThroughBlock(class_2338 pos, class_2350 direction, CallbackInfoReturnable<Boolean> cir) {
        if (client.field_1724 != null && client.method_1560() != null) {
            double d = client.field_1724.method_55755();
            class_243 vec3d = client.method_1560().method_5836(1f);
            class_243 vec3d2 = client.method_1560().method_5828(1f);
            class_3966 xrayResult = class_1675.method_18075(client.method_1560(), vec3d, vec3d.method_1031(vec3d2.field_1352 * d, vec3d2.field_1351 * d, vec3d2.field_1350 * d), client.method_1560().method_5829().method_18804(vec3d2.method_1021(d)).method_1009(1d, 1d, 1d), (entityx) -> {
                return !entityx.method_7325() && entityx.method_5863();
            }, d);
            if (client.field_1724 != null && xrayResult != null) {
                class_1799 stack = client.field_1724.method_5998(client.field_1724.method_6058());
                if (stack.method_7909() instanceof UseThroughBlock useThroughBlock && useThroughBlock.canAttackThroughBlock(client.field_1724, stack, xrayResult.method_17782())) {
                    useThroughBlock.onAttackThroughBlock(client.field_1724, stack, xrayResult.method_17782());
                    ClientPlayNetworking.send(new UseThroughBlock.AttackThroughBlock(xrayResult.method_17782().method_5628()));
                }
            }
        }
    }

    @Inject(method = "attackEntity", at = @At("HEAD"), cancellable = true)
    private void creo$doNotAttackItemEntities(class_1657 player, class_1297 target, CallbackInfo ci) {
        if (target instanceof class_1542)
            ci.cancel();
    }
}