package dev.creoii.greatbigworld.mixin.client;

import net.minecraft.class_1937;
import net.minecraft.class_2902;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_761.class)
public class WorldRendererMixin {
    @Redirect(method = "renderWeather", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;getTopY(Lnet/minecraft/world/Heightmap$Type;II)I"))
    private int creo$applyWeatherRenderIgnores(class_1937 instance, class_2902.class_2903 heightmap, int x, int z) {
        return instance.method_8624(class_2902.class_2903.valueOf("WEATHER"), x, z);
    }
}