package dev.creoii.greatbigworld.mixin.client;

import com.llamalad7.mixinextras.sugar.Local;
import dev.creoii.greatbigworld.block.OverlayState;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_287;
import net.minecraft.class_4076;
import net.minecraft.class_4587;
import net.minecraft.class_5819;
import net.minecraft.class_750;
import net.minecraft.class_776;
import net.minecraft.class_8251;
import net.minecraft.class_853;
import net.minecraft.class_9810;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_9810.class)
public class SectionBuilderMixin {
    @Shadow @Final private class_776 blockRenderManager;

    @Inject(method = "build", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/block/BlockRenderManager;renderBlock(Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/world/BlockRenderView;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;ZLnet/minecraft/util/math/random/Random;)V"))
    private void gbw$renderBlockOverlays(class_4076 sectionPos, class_853 renderRegion, class_8251 vertexSorter, class_750 allocatorStorage, CallbackInfoReturnable<class_9810.class_9811> cir, @Local class_4587 matrixStack, @Local class_5819 random, @Local(ordinal = 2) class_2338 blockPos3, @Local class_287 bufferBuilder, @Local class_2680 blockState) {
        if (blockState.method_26204() instanceof OverlayState overlayState) {
            class_2680 overlay = overlayState.getOverlayState(blockState, blockPos3, random);
            if (overlay.method_26204() != class_2246.field_10124) {
                blockRenderManager.method_3355(overlay, blockPos3, renderRegion, matrixStack, bufferBuilder, true, random);
            }
        }
    }
}
