package dev.creoii.greatbigworld.mixin;

import dev.creoii.greatbigworld.block.AdjacentCollision;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1313;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;

@Mixin(class_1297.class)
public class EntityMixin {
    @Inject(method = "move", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/profiler/Profiler;pop()V", ordinal = 2))
    private void gbw$collideAdjacentBlock(class_1313 movementType, class_243 movement, CallbackInfo ci) {
        class_1297 entity = (class_1297) (Object) this;
        Optional<class_2338> optionalPos = class_2338.method_25997(entity.method_24515(), (int) (entity.method_17681() + .5f), (int) (entity.method_17682() + .5f), pos -> {
            return entity.method_37908().method_8320(pos).method_26204() instanceof AdjacentCollision;
        });
        if (optionalPos.isPresent()) {
            class_2338 pos = optionalPos.get();
            class_2680 state = entity.method_37908().method_8320(pos);
            if (state.method_26204() instanceof AdjacentCollision adjacentCollision) {
                if (adjacentCollision.canEntityCollideAdjacent(entity, state, pos)) {
                    adjacentCollision.onAdjacentEntityCollision(entity, state, pos);
                }
            }
        }
    }
}
