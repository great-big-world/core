package dev.creoii.greatbigworld.mixin;

import dev.creoii.greatbigworld.tag.GBWBlockTags;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.function.Predicate;
import net.minecraft.class_2680;
import net.minecraft.class_2902;

@Mixin(class_2902.class_2903.class)
public class HeightmapTypeMixin {
    @SuppressWarnings("InvokerTarget")
    @Invoker("<init>")
    private static class_2902.class_2903 create(String internalName, int internalId, String name, class_2902.class_2904 purpose, Predicate<class_2680> blockPredicate) {
        throw new AssertionError();
    }

    @Shadow @Final @Mutable private static class_2902.class_2903[] field_13199;

    @SuppressWarnings("deprecation")
    @Inject(method = "<clinit>", at = @At(value = "FIELD", opcode = Opcodes.PUTSTATIC, target = "Lnet/minecraft/world/Heightmap$Type;field_13199:[Lnet/minecraft/world/Heightmap$Type;", shift = At.Shift.AFTER))
    private static void gbw$addWeatherHeightmap(CallbackInfo ci) {
        ArrayList<class_2902.class_2903> types = new ArrayList<>(Arrays.asList(field_13199));
        class_2902.class_2903 last = types.getLast();

        class_2902.class_2903 weather = create("WEATHER", last.ordinal() + 1, "WEATHER", class_2902.class_2904.field_16424, state -> {
            if (state.method_26164(GBWBlockTags.WEATHER_RENDER_IGNORES))
                return false;
            else return state.method_51366() || !state.method_26227().method_15769();
        });
        types.add(weather);

        field_13199 = types.toArray(new class_2902.class_2903[0]);
    }
}
