package dev.creoii.greatbigworld.block;

import net.minecraft.class_2350;
import net.minecraft.class_2510;
import net.minecraft.class_2680;
import net.minecraft.class_2778;

public class TranslucentStairsBlock extends class_2510 {
    public TranslucentStairsBlock(class_2680 baseBlockState, class_2251 settings) {
        super(baseBlockState, settings);
    }

    protected boolean method_9522(class_2680 state, class_2680 stateFrom, class_2350 direction) {
        if (stateFrom.method_27852(this)) {
            if (stateFrom.method_11654(class_2510.field_11571) == direction && state.method_11654(class_2510.field_11571) != direction.method_10153()) {
                return false;
            } else if (stateFrom.method_11654(class_2510.field_11571) == direction && stateFrom.method_11654(class_2510.field_11565) == class_2778.field_12712 && (state.method_11654(class_2510.field_11571) == class_2350.values()[direction.method_10146() + 1] || state.method_11654(class_2510.field_11571) == class_2350.values()[direction.method_10146() - 1])) {
                return false;
            } else return true;
        }
        return super.method_9522(state, stateFrom, direction);
    }
}
