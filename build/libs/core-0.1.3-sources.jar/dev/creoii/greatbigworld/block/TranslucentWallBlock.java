package dev.creoii.greatbigworld.block;

import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2544;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import net.minecraft.class_9636;
import org.jetbrains.annotations.Nullable;

public class TranslucentWallBlock extends class_2544 {
    public TranslucentWallBlock(class_2251 settings) {
        super(settings);
    }

    public static class_2680 getMeltedState() {
        return class_2246.field_10382.method_9564();
    }

    protected boolean method_9522(class_2680 state, class_2680 stateFrom, class_2350 direction) {
        return stateFrom.method_27852(this) || super.method_9522(state, stateFrom, direction);
    }

    public void method_9556(class_1937 world, class_1657 player, class_2338 pos, class_2680 state, @Nullable class_2586 blockEntity, class_1799 tool) {
        super.method_9556(world, player, pos, state, blockEntity, tool);
        if (!class_1890.method_60138(tool, class_9636.field_51555)) {
            if (world.method_8597().comp_644()) {
                world.method_8650(pos, false);
                return;
            }

            class_2680 blockState = world.method_8320(pos.method_10074());
            if (blockState.method_51366() || blockState.method_51176()) {
                world.method_8501(pos, getMeltedState());
            }
        }

    }

    protected void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        if (world.method_8314(class_1944.field_9282, pos) > 11 - state.method_26193(world, pos)) {
            melt(state, world, pos);
        }
    }

    protected void melt(class_2680 state, class_1937 world, class_2338 pos) {
        if (world.method_8597().comp_644()) {
            world.method_8650(pos, false);
        } else {
            world.method_8501(pos, getMeltedState());
            world.method_8492(pos, getMeltedState().method_26204(), pos);
        }
    }
}
