package dev.creoii.greatbigworld.mixin.client;

import dev.creoii.greatbigworld.block.OverlayState;
import net.minecraft.class_1920;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5819;
import net.minecraft.class_776;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_776.class)
public abstract class BlockRenderManagerMixin {
    @Shadow public abstract void renderBlock(class_2680 state, class_2338 pos, class_1920 world, class_4587 matrices, class_4588 vertexConsumer, boolean cull, class_5819 random);

    @Inject(method = "renderBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/block/BlockModelRenderer;render(Lnet/minecraft/world/BlockRenderView;Lnet/minecraft/client/render/model/BakedModel;Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;ZLnet/minecraft/util/math/random/Random;JI)V"))
    private void gbw$renderOverlayStates(class_2680 state, class_2338 pos, class_1920 world, class_4587 matrices, class_4588 vertexConsumer, boolean cull, class_5819 random, CallbackInfo ci) {
        if (state.method_26204() instanceof OverlayState overlayState) {
            class_2680 overlay = overlayState.getOverlayState(state, pos, random);
            if (overlay != class_2246.field_10124.method_9564()) {
                renderBlock(overlay, pos, world, matrices, vertexConsumer, cull, random);
            }
        }
    }
}
